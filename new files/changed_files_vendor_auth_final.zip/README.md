# Multi Vendor E-Commerce Platform

## Features

### Customer
- Registration & Login
- Product Search
- Cart & Checkout
- Order History
- Reviews & Ratings
- Contact Form

### Vendor
- Vendor Login
- Product Management
- Order Management
- Sales Analytics

### Admin
- Dashboard Analytics
- Product Management
- Category Management
- Vendor Management
- Coupon Management
- Reports
- Banner Management

### API
- Products API
- Orders API
- Authentication API

## Security
- Password Hashing
- Session Based Authentication
- Role Based Access Control
- Input Validation
- CORS Configuration

## Installation
1. Import `ecommerce_db.sql`.
2. Configure database credentials in `db.php`.
3. Place the project folder in `htdocs`.
4. Start Apache and MySQL.
5. Open `http://localhost/project-name`.

## Tech Stack
- PHP
- MySQL
- Bootstrap
- JavaScript

## Before Resubmitting

### Frontend
- Homepage dynamic
- Product details page
- Variations (size/color)
- Search working
- Cart working
- Checkout creates order
- Profile page working
- Reviews working
- Contact form stores feedback

### Admin
- Login works
- Dashboard works
- Product CRUD
- Category CRUD
- Vendor CRUD
- Orders management
- Coupon management
- Reports page
- Banners management

### Vendor
- Vendor login works
- Dashboard works
- Product CRUD works
- Orders visible
- Analytics visible

### Database
- All required tables exist
- Product variations table populated
- Orders table populated
- Feedback table populated
- Reviews table populated

### Security
- `password_hash()`
- `password_verify()`
- Session checks
- CORS headers on API files
